<?php
/**
 *
 * @link       https://freehand.studio/
 * @since      1.0.0
 *
 * @package    Freehand_Sitemap_For_Yardi
 * @subpackage Freehand_Sitemap_For_Yardi/public
 * @author     Freehand Studio <sam@freehand.studio>
*/

class Freehand_Sitemap_For_Yardi {
	protected $loader;
	protected $plugin_name;
	protected $version;

	public function __construct() {
		if ( defined( 'PLUGIN_NAME_VERSION' ) ) {
			$this->version = PLUGIN_NAME_VERSION;
		} else {
			$this->version = '1.0.0';
        }
        
		$this->plugin_name = 'apartment-sitemap';

		$this->load_dependencies();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	private function load_dependencies() {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-apartment-sitemap-loader.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-apartment-sitemap-admin.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-apartment-sitemap-public.php';

		$this->loader = new Freehand_Sitemap_For_Yardi_Loader();
	}

	private function define_admin_hooks() {

		$plugin_admin = new Freehand_Sitemap_For_Yardi_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_plugin_admin_menu' );

		$plugin_basename = plugin_basename( plugin_dir_path( __DIR__ ) . $this->plugin_name . '.php' );
		$this->loader->add_filter( 'plugin_action_links_' . $plugin_basename, $plugin_admin, 'add_action_links' );

		$this->loader->add_action('admin_init', $plugin_admin, 'options_update');
	}

	private function define_public_hooks() {
		$plugin_public = new Freehand_Sitemap_For_Yardi_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		
		// AJAX actions
		$this->loader->add_action('wp_ajax_as_fetch_listings', $plugin_public, 'fetch_listings');
        $this->loader->add_action('wp_ajax_nopriv_as_fetch_listings', $plugin_public, 'fetch_listings');
        $this->loader->add_action('wp_ajax_as_fetch_floorplate', $plugin_public, 'fetch_floorplate');
        $this->loader->add_action('wp_ajax_nopriv_as_fetch_floorplate', $plugin_public, 'fetch_floorplate');
        $this->loader->add_action('wp_ajax_as_fetch_apartments_info', $plugin_public, 'fetch_apartments_info');
        $this->loader->add_action('wp_ajax_nopriv_as_fetch_apartments_info', $plugin_public, 'fetch_apartments_info');
        $this->loader->add_action('wp_ajax_as_fetch_floorplan_index', $plugin_public, 'fetch_floorplan_index');
        $this->loader->add_action('wp_ajax_nopriv_as_fetch_floorplan_index', $plugin_public, 'fetch_floorplan_index');
	}

	public function run() {
		$this->loader->run();
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_loader() {
		return $this->loader;
	}

	public function get_version() {
		return $this->version;
	}
}
