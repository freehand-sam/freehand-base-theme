<?php
/**
 *
 * @link              https://freehand.studio/
 * @since             1.0.0
 * @package           Freehand_Sitemap_For_Yardi
 *
 * @wordpress-plugin
 * Plugin Name:       Freehand Sitemap for Yardi
 * Plugin URI:        https://freehand.studio/
 * Description:       Plugin that connects to the Yardi API and integrates with Freehand Studio websites
 * Version:           1.0.0
 * Author:            Freehand
 * Author URI:        https://freehand.studio/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       freehand-sitemap-for-yardi
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'FREEHAND-SITEMAP-FOR-YARDI', '1.0.0' );

require plugin_dir_path( __FILE__ ) . 'includes/class-apartment-sitemap.php';

function run_Freehand_Sitemap_For_Yardi() {
	$plugin = new Freehand_Sitemap_For_Yardi();
	$plugin->run();
}

run_Freehand_Sitemap_For_Yardi();