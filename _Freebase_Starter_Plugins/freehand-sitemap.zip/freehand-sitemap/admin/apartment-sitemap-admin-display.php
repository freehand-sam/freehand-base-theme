<?php
/**
 * @link       https://freehand.studio/
 * @since      1.0.0
 *
 * @package    Freehand_Sitemap_For_Yardi
 * @subpackage Freehand_Sitemap_For_Yardi/admin/partials
 */
?>

<div class="wrap freehand-studio">
    <h2>Freehand Sitemap <span>For Yardi</span></h2>
    <h5>By <a href="https://freehand.studio/" target="_blank">Freehand</a></h5>

    <form method="post" name="Freehand_Sitemap_For_Yardi_settings" action="options.php"> 
    <?php
        $options = get_option($this->plugin_name);

        $apiKey = $options['apiKey'];
        $propertyId = $options['propertyId'];
        $floorIndex = $options['floorIndex'];

        settings_fields($this->plugin_name);
        do_settings_sections($this->plugin_name);
    ?>
        <div id="poststuff">
            <div class="postbox-container">
                <div class="postbox as-flex-container">
                    <div class="as-container">
                        <fieldset>
                            <label for="<?php echo $this->plugin_name; ?>-apiKey">API Key</label>
                            <legend class="screen-reader-text"><span><?php _e('APIKey', $this->plugin_name); ?></span></legend>
                            <input type="text" class="regular-text" id="<?php echo $this->plugin_name; ?>-apiKey" name="<?php echo $this->plugin_name; ?>[apiKey]" value="<?php if(!empty($apiKey)) echo $apiKey; ?>" required/>
                        </fieldset>
                    </div>
                    <div class="as-container">
                        <fieldset>
                            <label for="<?php echo $this->plugin_name; ?>-propertyId">Property ID</label>
                            <legend class="screen-reader-text"><span><?php _e('PropertyID', $this->plugin_name); ?></span></legend>
                            <input type="text" class="regular-text" id="<?php echo $this->plugin_name; ?>-propertyId" name="<?php echo $this->plugin_name; ?>[propertyId]" value="<?php if(!empty($propertyId)) echo $propertyId; ?>" required/>
                        </fieldset>
                    </div>
                    <div class="as-container">
                        <fieldset>
                            <label for="<?php echo $this->plugin_name; ?>-floorIndex">Floor Number Index</label>
                            <legend class="screen-reader-text"><span><?php _e('FloorIndex', $this->plugin_name); ?></span></legend>
                            <input type="number" class="regular-text" id="<?php echo $this->plugin_name; ?>-floorIndex" name="<?php echo $this->plugin_name; ?>[floorIndex]" value="<?php if(!empty($floorIndex)) echo $floorIndex; ?>" required/>
                            <p><i>For example: Units labeled with the floor number at the 2nd index would be 1120 (1st Floor) or 1301 (3rd Floor) where the 2nd digit is the floor number.<i></p>
                        </fieldset>
                    </div>                    
                </div>
            </div>
        </div>

        <?php submit_button('Save all changes', 'primary','submit', TRUE); ?>

        <p style="text-align: right;">&copy; <?php echo date("Y"); ?> Freehand</p>
    </form>

</div>