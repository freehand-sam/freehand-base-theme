<?php
/**
 *
 * @link       https://freehand.studio/
 * @since      1.0.0
 *
 * @package    Freehand_Sitemap_For_Yardi
 * @subpackage Freehand_Sitemap_For_Yardi/admin
 * @author     Freehand Studio <sam@freehand.studio>
 */

class Freehand_Sitemap_For_Yardi_Admin {
	private $plugin_name;
	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'apartment-sitemap-admin.css', array(), $this->version, 'all' );
	}
	
	public function add_plugin_admin_menu() {		
		add_options_page( 'Freehand Sitemap for Yardi API Setup', 'Freehand Sitemap for Yardi', 'manage_options', $this->plugin_name, array($this, 'display_plugin_setup_page'));
	}

	public function add_action_links( $links ) {
		$settings_link = array(
			'<a href="' . admin_url( 'options-general.php?page=' . $this->plugin_name ) . '">' . __('Settings', $this->plugin_name) . '</a>',
        );
        
		return array_merge(  $settings_link, $links );
	}

	public function display_plugin_setup_page() {
		include_once( 'apartment-sitemap-admin-display.php' );
	}

	public function options_update() {
		register_setting($this->plugin_name, $this->plugin_name, array($this, 'validate'));
	}

	public function validate($input) {    
		$valid = array();
		$valid['apiKey'] = (isset($input['apiKey']) && !empty($input['apiKey'])) ? sanitize_text_field($input['apiKey']) : '';
        $valid['propertyId'] = (isset($input['propertyId']) && !empty($input['propertyId'])) ? sanitize_text_field($input['propertyId']) : '';	
        $valid['floorIndex'] = (isset($input['floorIndex']) && !empty($input['floorIndex'])) ? sanitize_text_field($input['floorIndex']) : '';
		return $valid;
    }
}
