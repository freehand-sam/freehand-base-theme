(function ($) {
    let bedrooms = 'all',
        startingPrice = 0,
        endingPrice = 9999,
        moveInDate = '0-0',
        listings = [],
        success = false,
        units = [],
        selectedFloor = 0,
        apartmentsInfo = [],
        hasFetchedApartments = false,
        currentFloorplanImage = '',
        floorplanIndex = 0;

    setTimeout(() => {
        if ($('#siteplan').length) {
            fetchApartmentsInfo();
            fetchFloorplanIndex();

            $('#smInputMoveIn').on('change', function () {
                moveInDate = $('#smInputMoveIn').val().toString();
                if (success) {
                    $('#floorPlateResult').empty().append(currentFloorplanImage);
                    filterResults();
                }
            });

            $('#smInputBedrooms').on('change', function () {
                bedrooms = this.value.toString();
                if (success) {
                    $('#floorPlateResult').empty().append(currentFloorplanImage);
                    filterResults()
                }
            });

            $('#smInputPrice').on('change', function () {
                var prices = this.value.split('-');
                startingPrice = prices[0];
                endingPrice = prices[1];
                if (success) {
                    $('#floorPlateResult').empty().append(currentFloorplanImage);
                    filterResults();
                }
            });
        }
    }, 1000);

    $(document).on('click', '.floor-button', function (e) {
        e.preventDefault();

        $('.loading-pulse').show();
        $('.floor-button').removeClass('active');
        $(this).toggleClass('active');

        selectedFloor = $(this).data('floor');

        let postId = $(this).data('post_id'),
            row = $(this).data('target'),
            post = { row: row, post_id: postId, action: 'as_fetch_floorplate' };

        $.ajax({
            url: as_ajax_object.ajax_url,
            type: 'post',
            data: post,
            dataType: 'html',
            error: response => {
                console.log(response);
            }, success: response => {
                currentFloorplanImage = response;
                $('.loading-pulse').hide();
                $('#floorPlateResult').empty().append(response);
                if (success) { filterResults(); }
            }
        });
    });

    Date.prototype.addDays = function (days) {
        let date = new Date(this.valueOf());
        date.setDate(date.getDate() + days);
        return date;
    }

    function fetchListings() {
        let data = { 'action': 'as_fetch_listings' }
        $.ajax({
            type: 'POST',
            url: as_ajax_object.ajax_url,
            cache: false,
            data: data,
            dataType: 'json',
            success: response => {
                if (!response) return;
                success = true;
                listings = response
                filterResults();
                setupBedroomOptions();
            }, error: () => {
                success = false;
            }
        })
    }

    function fetchApartmentsInfo() {
        let data = { 'action': 'as_fetch_apartments_info' }

        $.ajax({
            type: 'POST',
            url: as_ajax_object.ajax_url,
            cache: false,
            data: data,
            dataType: 'json',
            success: response => {
                hasFetchedApartments = true;
                apartmentsInfo = response;
            }, error: error => {
                console.log('Error');
            }
        })
    }

    function fetchFloorplanIndex() {
        let data = { 'action': 'as_fetch_floorplan_index' }

        $.ajax({
            type: 'POST',
            url: as_ajax_object.ajax_url,
            cache: false,
            data: data,
            dataType: 'json',
            success: response => {
                floorplanIndex = response;
                $('.floor-numbers .floor-button:first-child').trigger('click');
                fetchListings();
            }, error: error => {
                console.log('Error');
            }
        })
    }

    function setupBedroomOptions() {
        let bedroomOptions = [],
            html = '<option value="all">Bedrooms: All</option>';

        listings.forEach(unit => {
            if (!bedroomOptions.includes(unit.Beds)) bedroomOptions.push(unit.Beds);
        });

        bedroomOptions.sort().forEach(option => {
            let name = option === '0' ? 'Studio' : `${option} Bedroom`;
            html = html + `<option value="${option}">${name}</option>`;
        });

        $('#smInputBedrooms').html(html);
    }

    function filterResults() {
        units = listings;

        if (bedrooms !== 'all') {
            units = $.grep(units, n => {
                return n.Beds == bedrooms;
            });
        }

        if (endingPrice != 0) {
            units = $.grep(units, n => {
                return Number(n.MinimumRent) > Number(startingPrice) && Number(n.MinimumRent) < Number(endingPrice);
            });
        }

        let now = new Date(),
            dates = moveInDate.split('-');

        if (Number(dates[1]) != 0) {
            let fromDate = Number(dates[0]) == 0 ? now.addDays(-365) : now.addDays(Number(dates[0])),
                toDate = now.addDays(Number(dates[1]));

            units = $.grep(units, n => {
                let madeReadyDate = new Date(n.AvailableDate);
                return madeReadyDate > fromDate && madeReadyDate < toDate;
            });
        }

        if (selectedFloor >= 0) {
            units = $.grep(units, n => {
                let floor = Number(n.ApartmentName.charAt(floorplanIndex - 1));

                return selectedFloor === floor;
            })
        }

        setupMatches();

        setTimeout(() => {
            setupFloorPopovers();
            zoomControls();
        }, 500);
    }

    function setupMatches() {
        $('#results > h3').html(`${units.length} Matches`);

        let html = '',
            dateOptions = {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            };

        units.forEach(unit => {
            let rent = numberWithCommas(Number(unit.MinimumRent)),
                sqft = numberWithCommas(Number(unit.SQFT)),
                today = new Date(),
                readyDate = new Date(unit.AvailableDate),
                availability = readyDate >= today ? `Available: ${readyDate.toLocaleDateString('en-US', dateOptions)}` : 'Available Now';

            html = html + `<a href="#" data-unitnumber="${unit.ApartmentName}" class="unit-match d-block"><strong>APT ${unit.ApartmentName}</strong> ${unit.FloorplanName}<br>${unit.Beds} Bed | ${Math.round(Number(unit.Baths))} Bath | ${sqft} SF<br>$${rent} <br>${availability}</a>`;
        });

        $('#unitResults').html(html);
        $('#results').animate({
            scrollTop: 0
        }, 500);
    }

    const numberWithCommas = x => {
        let parts = x.toString().split('.');
        return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    function setupFloorPopovers() {
        units.forEach(unit => {
            if ($(`#unit-${unit.ApartmentName}`).length) {
                let dateOptions = { year: 'numeric', month: 'long', day: 'numeric' },
                    rent = numberWithCommas(Number(unit.MinimumRent)),
                    madeReadyDate = new Date(unit.AvailableDate),
                    sqft = numberWithCommas(Number(unit.SQFT));

                $(`#unit-${unit.ApartmentName}`)
                    .addClass('available')
                    .attr('data-unitnumber', `${unit.ApartmentName}`)
                    .attr('data-toggle', 'popover')
                    .attr('data-trigger', 'hover')
                    .attr('data-container', 'body')
                    .attr('data-html', 'true')
                    .attr('data-original-title', `<h4>APT ${unit.ApartmentName} <strong>${unit.FloorplanName}</strong></h4>`)
                    .attr('data-content', `<p>${unit.Beds} BED | ${Math.round(Number(unit.Baths))} BATH | ${sqft} SQ FT <br>$${rent} </p><p>AVAILABLE: <br>${madeReadyDate.toLocaleDateString('en-US', dateOptions)}</p>`);
            }
        });

        $('[data-toggle="popover"]').popover();
    }

    function zoomControls() {
        $("#unitFloorplan").on("click", ".zoomIn", function () {
            const element = $(this).parent().data("target");
            $(`${element}`).removeClass("zoomed-out").addClass("zoomed-in");
        });

        $("#unitFloorplan").on("click", ".zoomOut", function () {
            const element = $(this).parent().data("target");
            $(`${element}`).removeClass("zoomed-in").addClass("zoomed-out");
        });

        $("#unitFloorplan").on("click", ".zoomReset", function () {
            const element = $(this).parent().data("target");
            $(`${element}`).removeClass("zoomed-out zoomed-in").css({ 'position': 'relative', 'top': '0px', 'left': '0px' });
        });
    }

    $(document).on('click', '.unit-match, [id^=unit-]', function (e) {
        e.preventDefault();

        if (!$(this).data('unitnumber')) return;

        let unitnumber = $(this).data('unitnumber'),
            unit = $.grep(units, n => {
                return n.ApartmentName == unitnumber;
            }),
            pdf = '',
            image = '',
            imageContainer = '',
            pdfContainer = '';

        if (hasFetchedApartments) {
            let apartment = $.grep(apartmentsInfo, n => {
                return n.title.toLowerCase().replace(' ', '').includes(unit[0].FloorplanName.toLowerCase().replace(' ', ''));
            });

            if (apartment[0] && apartment[0].image && apartment[0].pdf) {
                image = apartment[0].image;
                pdf = apartment[0].pdf;
            }
        }

        if (!image) {
            imageContainer = '<h2 class="text-center text-primary">Image Coming Soon</h2>';
        } else {
            imageContainer = `
                <div class="mt-4"><img id="unitImage" class="d-block mx-auto" src="${image}" alt="${unit[0].FloorplanName} UNIT PLAN"></div>
            `;
        }

        if (!pdf) {
            pdfContainer = '<div class="col-md-6"></div>';
        } else {
            pdfContainer = `<div class="col-md-6"><a class="btn btn-secondary btn-block" href="${pdf}" target="_blank">Download Floorplan <i class="fa fa-angle-right"></i></a></div>`
        }

        let modal = `
            <div id="floorplan-sitemap-modal" class="modal fade floorplate" tabindex="-1" role="dialog" aria-labelledby="floorplanLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-dark">
                            <h4 class="modal-title text-white" id="floorplanLabel">APT ${unit[0].ApartmentName} </h4>
                            <button type="button" class="close mr-1" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                            <div id="unitFloorplan" class="img-container">${imageContainer}</div>
                            <h4 class="mt-3">${unit[0].FloorplanName} FLOORPLAN</h4>
                            <p class="text-primary mb-3">${unit[0].Beds} Bed | ${Math.floor(Number(unit[0].Baths))} Bath | ${numberWithCommas(Number(unit[0].SQFT))} SF | Starting at $${numberWithCommas(Number(unit[0].MinimumRent))}</p>
                            <div class="row">
                                ${pdfContainer}
                                <div class="col-md-6"><a class="btn btn-primary btn-block" href="${unit[0].ApplyOnlineURL}" target="_blank" id="applyForApt">Apply <i class="fa fa-angle-right"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;

        $('#floorPlanModal').empty().append(modal);

        setTimeout(() => {
            $('#floorplan-sitemap-modal').modal('toggle');
        }, 100);
    });
})(jQuery);