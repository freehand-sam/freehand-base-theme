<?php
/**
 *
 * @link       https://freehand.studio/
 * @since      1.0.0
 *
 * @package    Freehand_Sitemap_For_Yardi
 * @subpackage Freehand_Sitemap_For_Yardi/public
 * @author     Freehand Studio <sam@freehand.studio>
*/

class Freehand_Sitemap_For_Yardi_Public {
	private $plugin_name;
	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->as_options = get_option($this->plugin_name);
	}

	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'freehand-sitemap.css', array(), $this->version, 'all' );
	}

	public function enqueue_scripts() {                 
        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'freehand-sitemap.js', array( 'jquery' ), $this->version, false );
        wp_localize_script($this->plugin_name, 'as_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
	}

	public function fetch_listings() {
        $params = '?requestType=apartmentAvailability&apiToken=' . $this->as_options['apiKey'] . '&propertyId=' . $this->as_options['propertyId'];
        $response = wp_remote_get('http://api.rentcafe.com/rentcafeapi.aspx' . $params);
        
        if (!is_wp_error ($response)) {
            echo $response['body'];
        }

        exit;
    }
    
    public function fetch_floorplate() {
        $row = $_POST['row'];
        $rows = get_field('floorplates', 'option');

        $arrContextOptions = array(
            "ssl" => array(
                "verify_peer" => false,
                "verify_peer_name" => false,
            ),
        );

        $specific_row = $rows[$row]; 
        $image = $specific_row['floorplan_svg_image']; 
        $floorname = $specific_row['floor'];
        $svg_file = file_get_contents($image, false, stream_context_create($arrContextOptions));
        $find_string = '<svg';
        $position = strpos($svg_file, $find_string);
        $svg = substr($svg_file, $position);
        echo '<header class="text-center mb-3"><h3>Floor ' .  $floorname  . '</h3></header> <div class="zoom-box"><div id="floorPlate">' . $svg . '</div></div>';

        wp_die();
    }

    public function fetch_apartments_info() {
        $args = array(
		    'post_type' => 'floorplans',
		    'posts_per_page' => -1,
		    'post_status' => 'publish',
		    'orderby' => 'menu_order'
        );
        
	    $floorplans = array();
	    $query = new WP_Query($args);

	    if ($query->have_posts()):
		    while ($query->have_posts()): $query->the_post();                
                $floorplan = array(
                    'title' => the_title('', '', false),
                    'image' => get_field('floorplan_image')['url'],
                    'pdf' => get_field('floorplan_pdf'),
                );
                array_push($floorplans, $floorplan);
            endwhile;
		    echo json_encode($floorplans);
		    wp_reset_postdata();
	    else:
		    echo 'No Apartments Found';
        endif;
        
        wp_die();
    }

    public function fetch_floorplan_index() {
        $options = get_option($this->plugin_name);
        $index = $options['floorIndex'] ? $options['floorIndex'] : 1;
        echo $index;
        wp_die();
    }    
}
