=== Plugin Name ===
Contributors: Sam Toerper, Shawn Patel
Tags: yardi, sitemap, freehand, freehand studio
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: Copyright 2019 Freehand Studio
License URI: https://freehand.studio/

This plugin has been created by Freehand and connects Freehand websites that contain a sitemap to the Yardi API.